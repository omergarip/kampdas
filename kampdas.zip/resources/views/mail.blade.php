birader uyeligini aktif edersen seviniriz. Tesekkurler. Sonra da testine geri don
