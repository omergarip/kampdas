<footer class="footer">
    <div class="footerbc">
        <div class="social text-center mb-3">
            <a title="Facebook" rel="nofollow" href="https://www.facebook.com/muhendislikyarismalari" target="_blank"><i class="fab fa-facebook-f"></i></a>
            <a title="Instagram" rel="nofollow" href="https://www.instagram.com/muhendislikyarismalari" target="_blank"><i class="fab fa-instagram"></i></a>
            <a title="Linkedin" rel="nofollow" href="https://www.linkedin.com/company/11293176/" target="_blank"><i class="fab fa-linkedin"></i></a>
            <a title="Twitter" rel="nofollow" href="https://twitter.com/muhyarismalari" target="_blank"><i class="fab fa-twitter"></i></a>
            <a title="Youtube" rel="nofollow" href="https://www.youtube.com/channel/UCvsJlfcDPMSr5SwjbZvwfMw" target="_blank"><i class="fab fa-youtube"></i></a>
        </div>
        <div class="links">
            <ul class="list-unstyled quick-links">
                <li id="hakkimizda"><a href="hakkimizda"><i class="fa fa-angle-double-right"></i>Hakkımızda</a></li>
                <li id="hikayemiz"><a href="hikayemiz"><i class="fa fa-angle-double-right"></i>Kullanıcı Sözleşmesi</a></li>
                <li><a id="iletisim" href="iletisim"><i class="fa fa-angle-double-right"></i>İletişim</a></li>
            </ul>
        </div>

        <div class="copyright mb-2">
            <p class="text-center">Bu Sitenin Tüm Hakları Kampdaş'a Aittir. &copy;  2020</p>
        </div>
    </div>
</footer>
