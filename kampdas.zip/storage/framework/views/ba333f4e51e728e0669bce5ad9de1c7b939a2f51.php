<?php $__env->startSection('title'); ?>
    <title>Kayıt Ol</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('includes.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <section id="section-login">
        <div class="limiter">
            <div class="container-login100" style="background-image: url('https://kampdas.org/img/camp_photo-min.jpg');">
                <div class="wrap-login100">
                    <form method="POST" action="<?php echo e(route('register')); ?>" class="login100-form validate-form">
                        <?php echo csrf_field(); ?>
                        <div class="login100-form-logo">
                            <img class="wrap-login100-logo" src=<?php echo e(asset('img/PNG.png')); ?> />
                        </div>
                        <span class="login100-form-title">
                            Kayıt Ol
                        </span>
                        <div class="wrap-input100 validate-input" data-validate = "Adınızı ve Soyadınızı Giriniz">
                            <span class="label-input100">Adınız Soyadınız</span>
                            <input class="input100" type="text" name="name" placeholder="Adınızı ve Soyadınızı Giriniz" value="<?php echo e(old('name')); ?>" autocomplete="name" autofocus>
                            <span class="focus-input100" data-symbol="&#xf206;"></span>
                        </div>
                        <div class="wrap-input100 validate-input" data-validate = "Kullanıcı Adınızı Giriniz">
                            <span class="label-input100">Kullanıcı Adınız</span>
                            <input class="input100" type="text" name="username" placeholder="Kullanıcı Adınızı Giriniz">
                            <span class="focus-input100" data-symbol="&#xf206;"></span>
                        </div>
                        <div class="wrap-input100 validate-input" data-validate = "Email Adresinizi Giriniz">
                            <span class="label-input100">Email Adresiniz</span>
                            <input class="input100" type="email" placeholder="Email Adresinizi Giriniz" name="email" value="<?php echo e(old('email')); ?>"  autocomplete="email">
                            <span class="focus-input100" data-symbol="&#xf206;"></span>
                        </div>
                        <div class="wrap-input100 validate-input" data-validate = "Yaşadığınız Şehri Giriniz">
                            <span class="label-input100">Şehriniz</span>
                            <select class="input100" type="text" placeholder="Yaşadığınız Şehri Giriniz" id="city" name="city" value="<?php echo e(old('city')); ?>"  autocomplete="city">
                                <option selected disabled hidden>Şehrinizi Seçiniz</option>
                            </select>
                            <span class="focus-input100" data-symbol="&#xf206;"></span>
                        </div>
                        <div class="wrap-input100 validate-input" data-validate = "Doğum Tarihinizi Giriniz">
                            <span class="label-input100">Doğum Tarihiniz</span>
                            <input class="input100" id="birthday" type="text" placeholder="Doğum Tarihinizi Giriniz" name="birthday" value="<?php echo e(old('birthday')); ?>"  autocomplete="birthday">
                            <span class="focus-input100" data-symbol="&#xf206;"></span>
                        </div>
                        <div class="wrap-input100 validate-input" data-validate="Şifrenizi Giriniz">
                            <span class="label-input100">Şifreniz</span>
                            <input class="input100" type="password" name="password" autocomplete="new-password" placeholder="Şifrenizi Giriniz">
                            <span class="focus-input100" data-symbol="&#xf190;"></span>
                        </div>
                        <div class="wrap-input100 validate-input" data-validate="Şifrenizi Tekrar Giriniz">
                            <span class="label-input100">Şifreniz (Tekrar)</span>
                            <input class="input100" type="password" name="password_confirmation" autocomplete="new-password" placeholder="Şifrenizi Tekrar Giriniz">
                            <span class="focus-input100" data-symbol="&#xf190;"></span>
                        </div>

                        <div class="container-login100-form-btn">
                            <div class="wrap-login100-form-btn">
                                <div class="login100-form-bgbtn"></div>
                                <button class="login100-form-btn">
                                    Kayıt Ol
                                </button>
                            </div>
                        </div>

                        <div class="txt1 text-center">
						<span>
							veya
						</span>
                        </div>

                        <div class="flex-c-m">
                            <a href="#" class="login100-social-item bg1">
                                <i class="fa fa-facebook"></i>
                            </a>
                            <a href="#" class="login100-social-item bg3">
                                <i class="fa fa-google"></i>
                            </a>
                        </div>

                        <div class="flex-col-c">
						<span class="txt1">
							veya
						</span>
                            <a href="<?php echo e(route('login')); ?>" class="txt2">
                                Giriş Yap
                            </a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </section>















































































































<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
    <script>
        flatpickr("#birthday");
    </script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\kampdas\resources\views/auth/register.blade.php ENDPATH**/ ?>