<?php $__env->startSection('title'); ?>
    <title><?php echo e($event->title); ?></title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('includes.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div style="height: 200px;z-index: -1"></div>
    <section id="section-event">
        <div class="container">
            <div class="row">
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                



                <div class="col-md-10 mx-auto">
                    <figure class="event">
                        <div class="event__header">
                            <img class="event__header-logo" src="<?php echo e(asset('img/camp-logo.png')); ?>" />
                            <p class="event__header-title"><?php echo e(Str::Limit($event->title,75)); ?></p>
                            <?php if(auth()->user()->id === $event->created_by): ?>
                                <a class="event__header-edit" href="<?php echo e(route('events.edit', $event->slug)); ?>" >
                                    <img src="<?php echo e(asset('img/editicon.png')); ?>" />
                                </a>
                            <?php endif; ?>
                        </div>
                        <div class="event__slider">
                            <div id="<?php echo e($event->slug); ?>" class="carousel slide" data-ride="carousel">
                                <div class="carousel-inner">
                                    <div class="carousel-item active">
                                        <img class="d-block w-100" src="<?php echo e(asset('img/hotel-1.jpg')); ?>" alt="First slide">
                                    </div>
                                    <div class="carousel-item">
                                        <img class="d-block w-100" src="<?php echo e(asset('img/hotel-2.jpg')); ?>" alt="Second slide">
                                    </div>
                                    <div class="carousel-item">
                                        <img class="d-block w-100" src="<?php echo e(asset('img/hotel-3.jpg')); ?>" alt="Third slide">
                                    </div>
                                </div>
                                <a class="carousel-control-prev" href="#<?php echo e($event->slug); ?>" role="button" data-slide="prev">
                                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                                    <span class="sr-only">Previous</span>
                                </a>
                                <a class="carousel-control-next" href="#<?php echo e($event->slug); ?>" role="button" data-slide="next">
                                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                                    <span class="sr-only">Next</span>
                                </a>
                            </div>
                        </div>
                        <div class="event__share">
                            <div class="event__share-button">
                                <span><i class="fas fa-share-alt"></i>  Paylaş</span>
                                <a class="fb" rel="nofollow" target="_blank"href="https://www.facebook.com/share.php?u=https://www.kampdas.org/etkinlik/<?php echo e($event->slug); ?>"
                                   data-link="https://www.facebook.com/share.php?u=https://www.kampdas.org/etkinlik/<?php echo e($event->slug); ?>">
                                    <i class="fab fa-facebook-f"></i>
                                </a>
                                <a id="share" class="tw" href="https://twitter.com/share?original_referer=/&text=&url=
                                        https://www.kampdas.org/etkinlik/<?php echo e($event->slug); ?>" data-link="https://twitter.com/share?original_referer=/&text=&url=
                                        https://www.kampdas.org/etkinlik/<?php echo e($event->slug); ?>" target="_blank">
                                    <i class="fab fa-twitter"></i><span></span>
                                </a>
                                <a id="share" class="ln"
                                   href="https://www.linkedin.com/cws/share?url=https://www.kampdas.org/etkinlik/<?php echo e($event->slug); ?>"
                                   data-link="https://www.linkedin.com/cws/share?url=https://www.kampdas.org/etkinlik/<?php echo e($event->slug); ?>"
                                   target="_blank">
                                    <i class="fab fa-linkedin"></i><span></span>
                                </a>
                                <a name="whatsapp" id="share" class="wp"
                                   href="https://api.whatsapp.com/send?text=https://www.kampdas.org/etkinlik/<?php echo e($event->slug); ?>" target="_blank">
                                    <i class="fab fa-whatsapp"></i><span></span>
                                </a>
                            </div>
                        </div>
                        <div class="event__location">
                            <div id="map" class="event__location-map"></div>
                        </div>
                        <div class="event__owner-header">
                            <h3>Etkinliği Oluşturan:</h3>
                        </div>
                        <div class="event__owner">
                            <?php if($event->user->photo == ''): ?>
                                <img class="event__owner-profile" src="https://www.pngkey.com/png/detail/230-2301779_best-classified-apps-default-user-profile.png">
                            <?php else: ?>
                                <img class="event__owner-profile" src="<?php echo e(asset('storage/'.$event->user->photo)); ?>">
                            <?php endif; ?>
                            <div class="event__owner-info">
                                <h4><?php echo e($event->user->name); ?></h4>
                                <h6><?php echo e('@' . $event->user->username); ?></h6>
                            </div>
                        </div>
                        <div class="event__description">
                            <p><?php echo e($event->description); ?></p>
                        </div>
                        <div class="event__attendee">
                            <div class="event__attendee-header">
                                <h3>Etkinliğe Katılanlar: <?php echo e($event->limit === 0 ? $event->users->count() + 1 : $event->users->count() + 1 . '/' . $event->limit); ?></h3>
                                <?php if(auth()->user()->id !== $event->created_by): ?>
                                    <?php if($event->users->count() + 1 === $event->limit && !$isAttended): ?>
                                        <button
                                            class="bttn bttn__events-attend" disabled="disabled">
                                            Kontenjan Doldu
                                        </button>
                                    <?php elseif($event->users->isEmpty()): ?>
                                        <form action="<?php echo e(route('events.attend', $event->slug)); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <button
                                                class="bttn bttn__events-attend">
                                                Katıl
                                                <div class="bttn__events-attend__horizontal"></div>
                                                <div class="bttn__events-attend__vertical"></div>
                                            </button>
                                        </form>
                                    <?php elseif($isAttended): ?>
                                        <form action="<?php echo e(route('events.leave', $event->slug)); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <button
                                                class="bttn bttn__events-leave">
                                                Ayrıl
                                                <div class="bttn__events-attend__horizontal"></div>
                                                <div class="bttn__events-attend__vertical"></div>
                                            </button>
                                        </form>
                                    <?php else: ?>
                                        <form action="<?php echo e(route('events.attend  ', $event->slug)); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <button
                                                class="bttn bttn__events-attend">
                                                Katıl
                                                <div class="bttn__events-attend__horizontal"></div>
                                                <div class="bttn__events-attend__vertical"></div>
                                            </button>
                                        </form>
                                    <?php endif; ?>
                                <?php endif; ?>

                            </div>
                            <div class="event__attendee-profile">
                                <?php if($event->users->count() > 0): ?>
                                    <?php $__currentLoopData = $event->users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($user->photo == ''): ?>
                                            <img src="https://www.pngkey.com/png/detail/230-2301779_best-classified-apps-default-user-profile.png">
                                        <?php else: ?>
                                            <img src="<?php echo e(asset('storage/'.$user->photo)); ?>">
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($event->user->photo == ''): ?>
                                        <img src="https://www.pngkey.com/png/detail/230-2301779_best-classified-apps-default-user-profile.png">
                                    <?php else: ?>
                                        <img src="<?php echo e(asset('storage/'.$event->user->photo)); ?>">
                                    <?php endif; ?>
                                <?php else: ?>
                                    <?php if($event->user->photo == ''): ?>
                                        <img src="https://www.pngkey.com/png/detail/230-2301779_best-classified-apps-default-user-profile.png">
                                    <?php else: ?>
                                        <img src="<?php echo e(asset('storage/'.$event->user->photo)); ?>">
                                    <?php endif; ?>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="event__comments">
                            <div class="fb-comments" data-href="http://kampdas.test/etkinlik/<?php echo e($event->slug); ?>" data-numposts="10" data-width="100%"></div>
                        </div>
                    </figure>
                </div>
            </div>
        </div>
        <div style="height: 200px;z-index: -1"></div>
    </section>
    <div id="fb-root"></div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

    <script async defer crossorigin="anonymous" src="https://connect.facebook.net/tr_TR/sdk.js#xfbml=1&version=v7.0" nonce="wwo9Zgxt"></script>
    <script>
        // Initialize and add the map
        function initMap() {
            // The location of Uluru
            var uluru = {lat: 37.5525, lng: 29.6814};
            // The map, centered at Uluru
            var map = new google.maps.Map(
                document.getElementById('map'), {zoom: 12, center: uluru});
            // The marker, positioned at Uluru
            var marker = new google.maps.Marker({position: uluru, map: map});
        }
    </script>
    <script async defer
            src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDpDW9uG7D9V4RMWQKJKO4iaYKijkOKmvI&callback=initMap">
    </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\kampdas\resources\views/events/show.blade.php ENDPATH**/ ?>