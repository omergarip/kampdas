<?php $__env->startSection('title'); ?>
    <title>Giriş Yap</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('includes.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <section id="section-login">
        <div class="limiter">
            <div class="container-login100" style="background-image: url('https://kampdas.org/img/camp_photo-min.jpg');">
                <div class="wrap-login100">
                    <form method="POST" action="<?php echo e(route('login')); ?>" class="login100-form validate-form">
                    <?php echo csrf_field(); ?>
                        <div class="login100-form-logo">
                            <img class="wrap-login100-logo" src=<?php echo e(asset('img/PNG.png')); ?> />
                        </div>
                        <span class="login100-form-title">
                            Giriş Yap
                        </span>
                        <div class="wrap-input100 validate-input" data-validate = "Kullanıcı Adınızı Giriniz">
                            <span class="label-input100">Kullanıcı Adınız</span>
                            <input class="input100" type="text" name="username" placeholder="Kullanıcı Adınızı Giriniz">
                            <span class="focus-input100" data-symbol="&#xf206;"></span>
                        </div>

                        <div class="wrap-input100 validate-input" data-validate="Şifrenizi Giriniz">
                            <span class="label-input100">Şifreniz</span>
                            <input class="input100" type="password" name="password" placeholder="Şifrenizi Giriniz">
                            <span class="focus-input100" data-symbol="&#xf190;"></span>
                        </div>

                        <div class="forgot-password text-right">
                            <a href="<?php echo e(route('password.request')); ?>">
                                Şifreni mi unuttun?
                            </a>
                        </div>

                        <div class="container-login100-form-btn">
                            <div class="wrap-login100-form-btn">
                                <div class="login100-form-bgbtn"></div>
                                <button class="login100-form-btn">
                                    Giriş Yap
                                </button>
                            </div>
                        </div>

                        <div class="txt1 text-center">
						<span>
							veya
						</span>
                        </div>

                        <div class="flex-c-m">
                            <a href="<?php echo e(url('/redirect')); ?>" class="login100-social-item bg1">
                                <i class="fa fa-facebook"></i>
                            </a>
                            <a href="#" class="login100-social-item bg3">
                                <i class="fa fa-google"></i>
                            </a>
                        </div>

                        <div class="flex-col-c">
						<span class="txt1">
							veya
						</span>

                            <a href="<?php echo e(route('register-form')); ?>" class="txt2">
                                Kayıt Ol
                            </a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </section>














































































<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\kampdas\resources\views/auth/login.blade.php ENDPATH**/ ?>