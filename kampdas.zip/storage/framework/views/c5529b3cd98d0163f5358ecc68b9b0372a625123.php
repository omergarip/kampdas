  <nav class="navbar navbar-expand-lg bg-secondary fixed-top text-uppercase km-nav" id="mainNav">
      <a class="navbar-brand js-scroll-trigger" href="<?php echo e(route('home')); ?>"><img class="logo-brand" src=<?php echo e(asset('img/kampdas-logo1.png')); ?> /> </a>
      <button class="navbar-toggler navbar-toggler-right text-uppercase bg-primary text-white rounded" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation"> Menü <i class="fas fa-bars"></i>
      </button>

      <div class="collapse navbar-collapse" id="navbarResponsive">

          <ul class="navbar-nav mr-auto">
              <li class="nav-item mx-0 mx-lg-1">
                  <a class="nav-link py-3 px-0 px-lg-3 rounded js-scroll-trigger"
                     href=<?php echo e(route('home')); ?>>
                      <i class="fas fa-home"></i>
                        Anasayfa
                  </a>
              </li>


          </ul>
          <ul class="navbar-nav">
              <?php if(!Auth::guest()): ?>
                  <li class="nav-item dropdown mx-0 mx-lg-1">




                          <a class="nav-link dropdown-toggle  py-3 px-0 px-lg-3 rounded js-scroll-trigger" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">

                              <img class="km-circle-icon-img" src="<?php echo e(auth()->user()->photo ?? 'https://www.pngkey.com/png/detail/230-2301779_best-classified-apps-default-user-profile.png'); ?>">
                              Profilim
                          </a>
                          <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                              <a href="<?php echo e(route('profile', auth()->user()->username)); ?>" class="dropdown-item">Kullanıcı Bilgilerim</a>
                              <a class="dropdown-item" href="<?php echo e(route('profile.events', auth()->user()->username)); ?>">Etkinliklerim</a>
                          </div>

                  </li>
                  <li id="notification_li" class="nav-item mx-0 mx-lg-1 mr-lg-3">

                      <a href="#" class="nav-link py-3 px-0 px-lg-3 rounded js-scroll-trigger" id="notificationLink">
                          Bildirimler  <span id="notification_count"><?php echo e($numOfNotifications ?? '' ? $numOfNotifications ?? '' : '0'); ?></span>
                      </a>

                      <div id="notificationContainer">
                          <div id="notificationTitle">
                              Bildirimler
                              <a href="<?php echo e(route('notifications.read')); ?> "><?php echo e($numOfNotifications ?? '' ? 'Okundu olarak isaretle' : ''); ?></a>
                          </div>
                          <div id="notificationsBody" class="notifications">
                              <ul>
                                  <?php if($notifications ?? ''): ?>
                                      <?php $__currentLoopData = $notifications ?? ''; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                          <li  class="<?php echo e($notification->read_at ? '' : 'unread-notification'); ?>">
                                              <a href="<?php echo e($notification->read_at ? route('events.show', $notification->data['slug']) : route('notification.read', $notification->id)); ?>">
                                                  <?php echo e($notification->data['message']); ?>

                                              </a>
                                          </li>
                                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                  <?php else: ?>
                                      <li>No notifications</li>
                                  <?php endif; ?>
                              </ul>
                          </div>
                      </div>

                  </li>




                  <li class="nav-item mx-0 mx-lg-1">
                      <a
                          class="nav-link py-3 px-0 px-lg-3 rounded js-scroll-trigger"
                          href=<?php echo e(route('logout')); ?>>
                            Çıkış Yap
                      </a>
                  </li>
              <?php else: ?>
                  <li class="nav-item mx-0 mx-lg-1">
                      <a
                          class="<?php echo e((request()->routeIs('login')) ? 'active' : ''); ?>

                              nav-link py-3 px-0 px-lg-3 rounded js-scroll-trigger"
                          href=<?php echo e(route('login')); ?>>
                          Giriş Yap
                      </a>
                  </li>
                  <li class="nav-item mx-0 mx-lg-1">
                      <a
                          class="<?php echo e((request()->routeIs('register-form')) ? 'active' : ''); ?>

                              nav-link py-3 px-0 px-lg-3 rounded js-scroll-trigger"
                          href=<?php echo e(route('register-form')); ?>>
                          Kayıt Ol
                      </a>
                  </li>
              <?php endif; ?>


          </ul>
      </div>
      <div>
      </div>

  </nav>
<?php /**PATH D:\xampp\htdocs\kampdas\resources\views/includes/navigation.blade.php ENDPATH**/ ?>