[<?php echo e($slot); ?>](<?php echo e($url); ?>)
<?php /**PATH D:\xampp\htdocs\kampdas\resources\views/vendor/mail/text/header.blade.php ENDPATH**/ ?>