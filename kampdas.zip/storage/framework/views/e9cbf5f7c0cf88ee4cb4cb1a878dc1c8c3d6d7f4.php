birader uyeligini aktif edersen seviniriz. Tesekkurler. Sonra da testine geri don
<?php /**PATH D:\xampp\htdocs\kampdas\resources\views/mail.blade.php ENDPATH**/ ?>