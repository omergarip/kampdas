<?php $__env->startSection('title'); ?>
    <title>Etkinlik Oluştur</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="container">
        <div class="card card-default">
            <div class="card-header">
                <?php echo e(isset($media) ? 'Fotoğrafları Düzenle' :  'Fotoğrafları Yükle'); ?>

            </div>

            <div class="card-body">
                <?php if(isset($media)): ?>
                    <?php $__currentLoopData = $media; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <form action="<?php echo e(route('media.delete', $m->id)); ?>" enctype="multipart/form-data" method="post">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button class="btn btn-danger mr-2">Sil</button>
                            <img style="width: 10rem;" class="my-2 img-fluid" src="<?php echo e(asset('storage/'.$m->image)); ?>"/>
                            <span hidden id="<?php echo e($m->id); ?>"><?php echo e($m->image); ?></span><br>
                        </form>


                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <div class="text-center mb-5">
                        <?php echo e($media->links()); ?>

                    </div>
                <?php endif; ?>
                <form action="<?php echo e(route('media.store',  $slug )); ?>" enctype="multipart/form-data" class="dropzone" id="my-dropzone">
                    <?php echo csrf_field(); ?>

                </form>
                <a class="btn btn-success mt-3" href="<?php echo e(route('events.show', $slug)); ?>">Etkinliği Oluştur</a>
            </div>

        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/dropzone/5.7.1/min/dropzone.min.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/dropzone/5.7.1/min/dropzone.min.js"></script>
    <script>
        Dropzone.options.myDropzone = {
            paramName: 'file',
            maxFilesize: 5, // MB
            maxFiles: 20,
            acceptedFiles: ".jpeg,.jpg,.png,.gif",
        };
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\kampdas\resources\views/media/create.blade.php ENDPATH**/ ?>