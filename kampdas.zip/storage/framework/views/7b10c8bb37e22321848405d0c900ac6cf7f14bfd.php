<?php echo e($slot); ?>

<?php /**PATH D:\xampp\htdocs\kampdas\resources\views/vendor/mail/text/subcopy.blade.php ENDPATH**/ ?>